package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.qameta.allure.Step;

public class homePageObjects {
	public WebDriver driver;

	public homePageObjects(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

	By containers = By.xpath("//button[contains(@class, 'selectedClass')]");
	By imageFilter = By.xpath("//div[@id ='imageFilterList']");
	By verifiedPublisherChkBox = By.xpath("//input[@value='store']");
	By officialImageschkbox = By.xpath("//input[@value='official']");
	By categoryFilter = By.xpath("//div[@id ='categoriesFilterList']");
	By analyticsChkBox = By.xpath("//input[@value='analytics']");
	By baseImagesChkBox = By.xpath("//input[@value='base']");
	By databasesChkBox = By.xpath("//input[@value='database']");
	By storageChkBox = By.xpath("//input[@value='storage']");
	By currentFilter = By.xpath("//div[@class='styles__currentFilterGroup___1awKt']/div");
	    
	@Step("To get the default open tab")
	public WebElement getContainers() {
		return driver.findElement(containers);
	}
    @Step("To get the driver for the Image Filter")
	public WebElement getImageFilter() {
		return driver.findElement(imageFilter);
	}

	public WebElement getverifiedPublisherChkBox() {
		return driver.findElement(verifiedPublisherChkBox);
	}
	

	public WebElement getofficialImageschkbox() {
		return driver.findElement(officialImageschkbox);
	}

	public WebElement getcategoryFilter() {
		return driver.findElement(categoryFilter);
	}

	public WebElement getanalyticsChkBox() {
		return driver.findElement(analyticsChkBox);
	}

	public WebElement getbaseImagesChkBox() {
		return driver.findElement(baseImagesChkBox);
	}

	public WebElement getdatabasesChkBox() {
		return driver.findElement(databasesChkBox);
	}

	public WebElement getstorageChkBox() {
		return driver.findElement(storageChkBox);
	}
	private List<WebElement> selects;
	public List<WebElement> getSelects(){
		selects =  driver.findElements(currentFilter);
	      return selects;
	}
}
