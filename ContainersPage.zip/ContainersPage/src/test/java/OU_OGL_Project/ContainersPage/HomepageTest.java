package OU_OGL_Project.ContainersPage;

import java.io.IOException;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import pageObjects.homePageObjects;
import resources.base;

public class HomepageTest extends base {
	public base base;
	public WebDriver driver;
	public Properties prop;

	@BeforeMethod // this method will be executed before every @test method
	public void setUp() throws IOException {
		base = new base();
		prop = base.initialize_Properties();
		driver = base.initialize_driver();
			}
	
	@AfterMethod // --this method will be executed after every test method
	public void tearDown() {
		driver.quit();
	}

	@Test(priority = 1, description = "verifying home page")
	@Severity(SeverityLevel.NORMAL)
	@Description("Test Case Description: Verify home page landing tab")
	@Story("Story Name: To check which is the default tab open on Page Load")
	public void basePageNavigation() throws IOException {
		//driver = initialize_driver();
		//driver.get("http://hub.docker.com/search");
		homePageObjects po = new homePageObjects(driver);

		// a. verify that the user lands in the "Containers" tab by default
		String defaultOpenTab = po.getContainers().getText();

		if (defaultOpenTab.equals("Containers")) {
			System.out.println("Containers tab is open by default");
		} else
			System.out.println("Containers tab is not open by default");

		// b. verify there are 2 check boxes under images with labels "Verified
		// Publisher"
		// and " Official Images

		WebElement imageFilterdriver = po.getImageFilter();
		List<WebElement> imagecheckboxes = imageFilterdriver.findElements(By.tagName("input"));
		int count1 = imagecheckboxes.size();
		System.out.println("Number of checkboxes under Images filter:" + count1);
		Assert.assertTrue(po.getverifiedPublisherChkBox().isEnabled());
		Assert.assertTrue(po.getofficialImageschkbox().isEnabled());

		// c. Under Categories, verify the following check boxes are present Analytics,
		// Base Images, Databases, Storage
		WebElement categoriesFilterDriver = po.getcategoryFilter();
		List<WebElement> categorycheckboxes = categoriesFilterDriver.findElements(By.tagName("input"));
		int count = categorycheckboxes.size();
		System.out.println("Number of checkboxes under Categories filter:" + count);
		Assert.assertTrue(po.getanalyticsChkBox().isEnabled());
		Assert.assertTrue(po.getbaseImagesChkBox().isEnabled());
		Assert.assertTrue(po.getdatabasesChkBox().isEnabled());
		Assert.assertTrue(po.getstorageChkBox().isEnabled());

	}

	@Test(priority = 2, description = "verifying current filter group on the search page")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Test Case Description: Verify whether the corresponding filter is displayed ")
	@Story("Story Name: To check whether the corresponding filter is displayed")
	public void groupFilterCheck() {
		//driver.get("http://hub.docker.com/search");
		homePageObjects po = new homePageObjects(driver);
		po.getverifiedPublisherChkBox().click();
		po.getbaseImagesChkBox().click();
		po.getdatabasesChkBox().click();
		String bi = "Base Images";
		String db = "Databases";
		String pc = "Publisher Content";
		List<WebElement> cfg = po.getSelects();
		ListIterator<WebElement> alldivs = cfg.listIterator();
		while (alldivs.hasNext()) {
			WebElement elem = alldivs.next();
			String cfgText = elem.getText();
			System.out.println(cfgText);
			if (cfgText.equals(bi)) {
				Assert.assertEquals(bi, cfgText);

			}
			if (cfgText.equals(db)) {
				Assert.assertEquals(db, cfgText);
				elem.click();
				//Assert.assertFalse(driver.findElement(By.xpath("//input[@value='database']")).isSelected());
				Assert.assertFalse(po.getdatabasesChkBox().isSelected());
						

			}
			if (cfgText.equals(pc)) {
				Assert.assertEquals(pc, cfgText);

			}
		}
	}
}
